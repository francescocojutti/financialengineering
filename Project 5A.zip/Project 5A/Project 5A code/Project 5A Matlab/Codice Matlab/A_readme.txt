A_readme
Ther is a folder named Workspace where there are the three workspaces relative to the different analysis( base and two robustness checks).
We inform that a complete run of the code (1000 simulation) last between 20 and 25 minutes depending on the RAM and the cores of the computer. We suggest to run it with parallel pool active.
